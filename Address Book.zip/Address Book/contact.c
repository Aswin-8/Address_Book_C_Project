#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "contact.h"
#include "file.h"
#include "populate.h"


void listContacts(AddressBook *addressBook) 
{
    int i;
    printf("Contacts: \n");
    printf("Name \t\t Phone.no \t  email id\n");
    for(i=0;i<addressBook->contactCount;i++)
    {
        printf("%s \t %s \t  %s\n",addressBook->contacts[i].name,addressBook->contacts[i].phone,addressBook->contacts[i].email);
    }
}

/*void initialize(AddressBook *addressBook) 
{
   populateAddressBook(addressBook) ;
} */

void saveAndExit(AddressBook *addressBook) 
{
}


void createContact(AddressBook *addressBook) 
{
    char Name[20],Phone[15],Email[20];
    int i,j,flag,pos;
    printf("Enter the details:\n");
    printf("Name: ");
    getchar();
    scanf("%19[^\n]",Name);
    printf("Phone: ");
    getchar();
    scanf("%15[^\n]",Phone);
    for(i=0;i<addressBook->contactCount;i++)
    {
       
        flag=strcmp(Phone, addressBook->contacts[i].phone);
        if(flag==0)
            {
                printf("Phone no already exists\n");
                printf("Phone: \n");
                getchar();
                scanf("%15[^\n]",Phone);
                flag=1;
                break;
            }
    }
    if(flag)
    {
        printf("Email: ");
        getchar();
        scanf("%20[^\n]",Email);
        for(i=0;i<addressBook->contactCount;i++)
        {
            flag=strcmp(Email, addressBook->contacts[i].email);
            if(flag==0)
            {
                printf("Email ID already exists\n");
                printf("Email: \n");
                getchar();
                scanf("%20[^\n]",Email);
                flag=1;
                break;
            }
        } 
        if(flag)
        {
            
            addressBook->contacts = realloc(addressBook->contacts,addressBook->contactCount+1 * sizeof(Contact));
            addressBook->contactCount++;
            pos=addressBook->contactCount;
            strcpy(addressBook->contacts[pos-1].name,Name);
            strcpy(addressBook->contacts[pos-1].phone,Phone);
            strcpy(addressBook->contacts[pos-1].email,Email);
        }
    }
}

void searchContact(AddressBook *addressBook) 
{
    int i,flag=1,opt;
    char str[20];
    getchar();
    printf("1.search by name\n");
    printf("2.search by phone number\n");
    printf("3.search by mail_id\n");
    printf("Select an option: \n");
    scanf("%d",&opt);
    switch(opt)
    {
        case 1:printf("Enter the name :\n");
        getchar();
        scanf("%[^\n]",str);
        for(i=0;i<addressBook->contactCount;i++)
        {
            flag=(strcmp(str, addressBook->contacts[i].name) );
            if(flag==0)
            {
            printf("%s \t %s \t  %s\n",addressBook->contacts[i].name,addressBook->contacts[i].phone,addressBook->contacts[i].email);
            break;
            }
        }
        break;
        case 2:printf("Enter the phone number :\n");
        getchar();
        scanf("%[^\n]",str);
        for(i=0;i<addressBook->contactCount;i++)
        {
            flag=(strcmp(str, addressBook->contacts[i].phone) );
            if(flag==0)
            {
            printf("%s \t %s \t  %s\n",addressBook->contacts[i].name,addressBook->contacts[i].phone,addressBook->contacts[i].email);
            break;
            }
        }
        break;
        case 3:printf("Enter the email id :\n");
        getchar();
        scanf("%[^\n]",str);
        for(i=0;i<addressBook->contactCount;i++)
        {
            flag=(strcmp(str, addressBook->contacts[i].email) );
            if(flag==0)
            {
            printf("%s \t %s \t  %s\n",addressBook->contacts[i].name,addressBook->contacts[i].phone,addressBook->contacts[i].email);
            break;
            }
        }
        break;
        default: printf("Enter a valid option\n");
    }
    if(flag)
    {
        printf("Contact not found\n");
    }
}

void editContact(AddressBook *addressBook) 
{
    int i,index,flag=1,opt;
    
    printf("1.edit the name\n");
    printf("2.edit the  phone number\n");
    printf("3.edit the mail_id\n");
    printf("Select an option: \n");
    scanf("%d",&opt);
    char str[20],Name[20],Phone[15],Email[20];
    switch(opt)
    {
        case 1:printf("Enter the name to be edited:\n");
        getchar();
        scanf("%[^\n]",str);
        for(i=0;i<addressBook->contactCount;i++)
        {
            flag=(strcmp(str, addressBook->contacts[i].name) );
            if(flag==0)
            {
            printf("Enter the name: \n");
            getchar();
            scanf("%19[^\n]",Name);
            printf("Contact updated successfully.\n");
            index=i;
            strcpy(addressBook->contacts[index].name,Name);
            break;
            }
        }
        break;

        case 2:printf("Enter the phone number to be edited:\n");
        getchar();
        scanf("%[^\n]",str);
        for(i=0;i<addressBook->contactCount;i++)
        {
            flag=(strcmp(str, addressBook->contacts[i].phone) );
            if(flag==0)
            {
            printf("Enter the phone number: \n");
            getchar();
            scanf("%14[^\n]",Phone);
            printf("Contact updated successfully.\n");
            index=i;
            strcpy(addressBook->contacts[index].phone,Phone);
            break;
            }
        }
        break;

        case 3:printf("Enter the email id to be edited:\n");
        getchar();
        scanf("%[^\n]",str);
        for(i=0;i<addressBook->contactCount;i++)
        {
            flag=(strcmp(str, addressBook->contacts[i].email) );
            if(flag==0)
            {
            printf("Enter the mail id: \n");
            getchar();
            scanf("%19[^\n]",Email);
            printf("Contact updated successfully.\n");
            index=i;
            strcpy(addressBook->contacts[index].email,Email);
            break;
            }
        }
        break;
        default :printf("Invalide option");
    }
    if(flag)
    {
        printf("Contact not found\n");
    }
}

void deleteContact(AddressBook *addressBook) 
{
    char str[20];
    int *ptr;
    int i,j,flag;
    printf("Enter the name: ");
    getchar();
    scanf("%19[^\n]",str);
    for(i=0;i<addressBook->contactCount;i++)
    {
        flag=strcmp(str, addressBook->contacts[i].name);
        if(flag==0)
        {
            for(j=i;j<addressBook->contactCount;j++)
            {
                addressBook->contacts[j]=addressBook->contacts[j+1];
            }
            printf("Contact deleted succesfully\n");
            break;
        }
    }
    ptr = realloc(addressBook->contacts,addressBook->contactCount-1 * sizeof(Contact));
    addressBook->contactCount--;
    if(flag)
    {
        printf("Contact not found\n");
    }
}
