#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "file.h"

void saveContactsToFile(AddressBook *addressBook) 
{
    
}

void loadContactsFromFile(AddressBook *addressBook) 
{
    addressBook->fptr=fopen("addressbook.csv","r");
    if(addressBook->fptr == NULL)
    {
        printf("File not found");
        return ;
    }
    char str[30];
    int num;
    fscanf(addressBook->fptr,"%s",str);  
    num=atoi(strtok(str+1,"#"));
printf("num = %d\n", num);
    addressBook->contactCount=num;
    addressBook->contacts=malloc(num * sizeof(Contact)); 
    
        fgetc(addressBook->fptr);
    for(int i=0;i<num;i++)
    { 
        fgetc(addressBook->fptr);
        fscanf(addressBook->fptr,"%[^\n]",str); 
        strcpy(addressBook->contacts[i].name, strtok(str,","));
        strcpy(addressBook->contacts[i].phone,strtok(NULL,","));
        strcpy(addressBook->contacts[i].email,strtok(NULL,",")); 
printf("%s %s %s\n", addressBook->contacts[i].name, addressBook-> contacts[i].phone, addressBook-> contacts[i].email);
    } 
}
